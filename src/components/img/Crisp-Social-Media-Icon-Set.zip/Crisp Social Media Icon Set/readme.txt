------------------
Crisp Social Media Icon Set
25 Social Icons
PNG Format
Designed by Chris Thurman - http://www.christhurman.com/
Exclusively for Visual Swirl - http://www.visualswirl.com/
------------------

Thank you for downloading this icon set!

These icons are free for personal and commercial use without attribution or exception. The set may not be resold, sub-licensed, rented, transferred or otherwise made available for use. Please link to this article if you would like to share this set. Enjoy!

For more resources, tutorials, and articles visit http://www.visualswirl.com/

For questions or concerns email info@visualswirl.com. 

Enjoy,
Visual Swirl
www.visualswirl.com